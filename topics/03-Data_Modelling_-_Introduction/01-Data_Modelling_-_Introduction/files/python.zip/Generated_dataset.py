# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.10.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Curve Fitting

# %% [raw]
# %load_ext autoreload
# %autoreload 2

# %%
import numpy as np
import generate_fit_linear_reg as model

model.generate_fit_linear_reg(2, model.data, show_fit=1, show_error=1);

# %% [markdown] jupyter={"outputs_hidden": true}
# ## Animation

# %%
from ipywidgets import interact, interactive, fixed, interact_manual
import ipywidgets as widgets

def f_anim(degree, m):
    model.generate_fit_linear_reg(degree, model.data, m=m, show_fit=1, show_error=1);

interact(f_anim, 
         degree = widgets.IntSlider(value=5, min=1, max=20, step=1),
         m = widgets.IntSlider(value=30, min=5, max=30, step=1)
        )

# %%
