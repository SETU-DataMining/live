df = pd.read_csv("data/tips.csv")
print(df.shape)
df.head(10)