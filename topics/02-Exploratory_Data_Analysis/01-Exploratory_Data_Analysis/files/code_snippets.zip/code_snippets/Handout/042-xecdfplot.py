sns.ecdfplot(data=df2, x="x")
plt.show()
