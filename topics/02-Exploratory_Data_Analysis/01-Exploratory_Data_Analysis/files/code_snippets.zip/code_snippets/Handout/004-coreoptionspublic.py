sns.set_style('darkgrid')   
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)