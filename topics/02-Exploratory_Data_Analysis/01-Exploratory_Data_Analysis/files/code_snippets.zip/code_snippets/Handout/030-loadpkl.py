df = pd.read_pickle('output/analysis.pkl')
print(df.shape)
df.head(1)