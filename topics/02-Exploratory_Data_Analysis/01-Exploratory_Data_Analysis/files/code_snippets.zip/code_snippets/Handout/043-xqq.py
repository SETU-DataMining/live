import pingouin as pg
pg.qqplot(df2.x)
plt.show()
