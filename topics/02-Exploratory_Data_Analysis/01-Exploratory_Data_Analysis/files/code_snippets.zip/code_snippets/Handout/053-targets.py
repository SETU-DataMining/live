targets = [c for c in df.columns if c[0]=="a"]
targets