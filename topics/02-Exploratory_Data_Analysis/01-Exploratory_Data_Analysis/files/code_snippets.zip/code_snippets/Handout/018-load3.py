df = pd.read_table('data/analysis.txt', sep=r'\s+', header=None)
print(df.shape)
df.head()