sns.countplot(x="Survived", data=df)
plt.show()