sns.boxplot(x="x", data=df2)
plt.show()
