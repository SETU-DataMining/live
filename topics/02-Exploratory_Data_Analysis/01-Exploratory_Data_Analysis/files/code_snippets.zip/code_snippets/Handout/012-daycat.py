df.day = pd.Categorical(df.day, categories=['Thur', 'Fri','Sat', 'Sun'], ordered=True)
df.day.unique()