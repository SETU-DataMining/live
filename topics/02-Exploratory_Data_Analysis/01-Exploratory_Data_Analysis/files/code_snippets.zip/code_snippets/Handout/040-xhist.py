sns.histplot(x="x", data=df2, kde=True)
plt.show()
