sns.countplot(x="Size", data=df)
plt.show()
