sns.countplot(x="Sex", hue="Survived", data=df)
plt.show()