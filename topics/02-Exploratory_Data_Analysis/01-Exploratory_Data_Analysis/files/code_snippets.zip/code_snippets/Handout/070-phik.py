import phik
columns = df.columns[:12]
corr = df[columns].phik_matrix()
corr