df = pd.read_csv("data/train.csv")
sns.catplot(data=df, x="Fare", y="Survived")
plt.show()