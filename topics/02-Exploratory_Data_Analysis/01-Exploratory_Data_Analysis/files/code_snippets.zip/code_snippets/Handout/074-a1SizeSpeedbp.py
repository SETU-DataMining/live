sns.boxplot(x="a1", y="Size", hue="Speed", data=df)
plt.show()
