columns = df.columns[3:12]
corr = df[columns].corr()
corr