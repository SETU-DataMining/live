sns.boxplot(x="a1", y="Size", data=df)
plt.show()
