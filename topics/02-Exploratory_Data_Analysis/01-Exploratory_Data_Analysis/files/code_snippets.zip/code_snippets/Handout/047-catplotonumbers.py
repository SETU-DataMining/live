df = pd.read_csv("data/train.csv")
df.Survived = df.Survived.astype(str)
sns.catplot(data=df, x="Fare", y="Survived")
plt.show()