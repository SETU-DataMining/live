sns.countplot(y="size", data=df)
plt.show()
