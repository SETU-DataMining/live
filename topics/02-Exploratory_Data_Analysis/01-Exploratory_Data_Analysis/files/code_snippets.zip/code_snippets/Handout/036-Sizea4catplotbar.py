sns.catplot(x="Size", y="a4", data=df, kind='bar')
plt.show()
