df = pd.read_feather('output/analysis.feather')
print(df.shape)
df.head(1)