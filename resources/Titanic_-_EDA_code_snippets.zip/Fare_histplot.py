sns.histplot(data=df, x="Fare", kde=True)
plt.show()