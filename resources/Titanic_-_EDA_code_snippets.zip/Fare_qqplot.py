pg.qqplot(df.Fare)
plt.show()