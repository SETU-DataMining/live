import seaborn as sns
import scipy.stats as stats
import statsmodels.api as sm
import pingouin as pg

from IPython.display import display, Markdown

sns.set_style('darkgrid')   
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)