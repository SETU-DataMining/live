tmp = df.groupby("Ticket")['Fare'].nunique()
tmp[tmp>1]