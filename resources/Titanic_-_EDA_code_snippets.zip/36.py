df = pd.read_csv("data/train.csv")
df.columns