df = pd.read_csv("data/train.csv")
print(df.shape)
df.head(25)