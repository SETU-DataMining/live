df.Sex = pd.Categorical(df.Sex)
df.Pclass = pd.Categorical(df.Pclass, categories=[1, 2, 3], ordered=True)
df.Survived = pd.Categorical(df.Survived)