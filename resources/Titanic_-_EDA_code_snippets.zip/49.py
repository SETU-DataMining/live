if False:
    from pandas_profiling import ProfileReport
    profile = ProfileReport(df, title="Titanic Report", html={"style": {"full_width": True}}, sort="None")
    profile