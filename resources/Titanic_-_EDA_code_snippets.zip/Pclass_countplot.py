sns.countplot(x="Pclass", hue="Survived", data=df)
plt.show()