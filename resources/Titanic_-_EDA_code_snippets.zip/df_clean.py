col = df.pop("Survived")
df[col.name] = col
df.head(20)