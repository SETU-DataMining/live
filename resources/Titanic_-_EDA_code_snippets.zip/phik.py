columns = ["Pclass","Sex", "Age", "SibSp", "Parch", "Fare", "Embarked", "Survived"]
df[columns].phik_matrix()