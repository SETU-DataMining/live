df = pd.read_csv("data/train.csv")
df.Survived = df.Survived.map( {0:"no", 1:"yes"} )
sns.catplot(data=df, x="Fare", y="Survived")
plt.show()