sns.catplot(data=df, x="Fare", row="Survived", kind='box')
plt.show()