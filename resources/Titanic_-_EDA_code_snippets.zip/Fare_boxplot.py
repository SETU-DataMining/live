sns.boxplot(data=df, x="Fare")
plt.show()