targetCol = 'a1'
predictorsC = [x for x in df.columns if (x[0] != 'a') or (x == targetCol)] 
sns.pairplot(df[predictorsC])