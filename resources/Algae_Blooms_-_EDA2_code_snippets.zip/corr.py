columns = df.columns[:12]
corr = df[columns].corr(numeric_only=True)
corr