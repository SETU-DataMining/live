columns = df.columns[:12]
corr = df[columns].corr(method='spearman',numeric_only=True)
corr