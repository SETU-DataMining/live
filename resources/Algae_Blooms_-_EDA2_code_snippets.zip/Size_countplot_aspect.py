plt.figure(figsize=(8,6))
sns.countplot(x="Size", data=df)
plt.savefig("pic/Size_countplot.pdf", bbox_inches="tight")