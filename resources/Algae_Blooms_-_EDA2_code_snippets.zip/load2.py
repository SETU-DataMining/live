df = pd.read_table('src/Analysis.txt', header=None)
print(df.shape)
df.head()