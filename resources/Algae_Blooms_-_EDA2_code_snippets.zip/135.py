#from pandas_profiling import ProfileReport
#profile = ProfileReport(df, title="Algae Blooms Report", html={"style": {"full_width": True}}, sort="None")
#profile