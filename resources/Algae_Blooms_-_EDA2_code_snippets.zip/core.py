import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# See https://stackoverflow.com/a/74716639/1988855
plt.style.use('seaborn-v0_8-darkgrid')