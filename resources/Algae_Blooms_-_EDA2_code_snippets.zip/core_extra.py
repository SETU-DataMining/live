import seaborn as sns
import scipy.stats as stats
import statsmodels.api as sm
import pingouin as pg

from IPython.display import display, Markdown
#import matplotlib as mpl
#mpl.rcParams['figure.dpi']= 150
sns.set_style('darkgrid')
sns.set_context('talk')