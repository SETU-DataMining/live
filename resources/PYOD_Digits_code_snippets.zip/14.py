yTrain = y_train['label'].to_numpy()
yTest = y_test['label'].to_numpy()