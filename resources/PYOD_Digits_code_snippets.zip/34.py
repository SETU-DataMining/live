y_test_score_prob = knn.predict_proba(X_test, method='linear')
y_test_score_prob