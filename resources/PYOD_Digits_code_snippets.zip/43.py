from IPython.display import IFrame
IFrame("data/selected_pyod.pdf", width=700, height=600)