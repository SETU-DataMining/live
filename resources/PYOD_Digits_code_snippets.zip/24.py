y_test_pred = knn.predict(X_test)  
y_test_pred