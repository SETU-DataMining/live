y_test_scores = knn.decision_function(X_test)
y_test_scores