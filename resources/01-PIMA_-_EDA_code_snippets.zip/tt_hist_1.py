sns.histplot(x="triceps_thickness", data=df)
plt.title("triceps_thickness by onset_diabetes")
plt.show()
