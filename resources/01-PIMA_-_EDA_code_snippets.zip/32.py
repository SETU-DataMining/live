sns.histplot(x="serum_insulin", data=df, bins=50)
plt.title("serum_insulin by onset_diabetes")
plt.show()
