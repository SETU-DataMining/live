sns.catplot(x="plasma_glucose_concentration", y="onset_diabetes", kind='box', data=df,  orient="h")
plt.title("plasma_glucose_concentration by onset_diabetes")
plt.show()
