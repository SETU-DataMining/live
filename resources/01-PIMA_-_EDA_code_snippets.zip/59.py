model = KNeighborsClassifier(n_neighbors=11)
scores = cross_val_score(model, X, y, cv=10, n_jobs=-1)
score_report(scores)