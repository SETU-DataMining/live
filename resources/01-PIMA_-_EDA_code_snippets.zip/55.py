print(df.shape)
df.describe()