sns.catplot(x="serum_insulin", y="onset_diabetes", kind='box', data=df, orient='h')
plt.title("serum_insulin by onset_diabetes")
plt.show()
