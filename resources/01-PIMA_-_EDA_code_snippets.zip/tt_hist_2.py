sns.histplot(x="triceps_thickness", data=df, bins=30)
plt.title("triceps_thickness by onset_diabetes")
plt.show()
