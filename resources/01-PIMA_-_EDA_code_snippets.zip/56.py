df2 = df.dropna()
print(df2.shape)
df2.describe()