from sklearn.experimental import enable_iterative_imputer
pipeline = Pipeline([
    ( 'imp', impute.IterativeImputer(max_iter=10, random_state=0) ),
    ( 'model', LogisticRegression() )
]) 

X, y  = df[features].values, df.onset_diabetes.values
print(X.shape)

scores = cross_val_score(pipeline, X, y, cv=10, n_jobs=-1)
score_report(scores)