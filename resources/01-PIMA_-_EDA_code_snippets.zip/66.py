pipeline = Pipeline([
    ( 'imp', impute.SimpleImputer(strategy='mean') ),
    ( 'standardize', preprocessing.MinMaxScaler() ),
    ( 'model', LogisticRegression() )
]) 

X, y  = df[features].values, df.onset_diabetes.values

scores = cross_val_score(pipeline, X, y, cv=10, n_jobs=-1)
score_report(scores)