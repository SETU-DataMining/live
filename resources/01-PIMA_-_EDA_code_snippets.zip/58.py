features = df2.columns[:-1]
X, y  = df2[features].values, df2.onset_diabetes.values
X.shape, y.shape