pipeline = Pipeline([
    ( 'imp', impute.SimpleImputer(strategy='mean') ),
    ( 'model', LogisticRegression() )
]) 

df2 = df.dropna()
X, y  = df2[features].values, df2.onset_diabetes.values
print(X.shape)

scores = cross_val_score(pipeline, X, y, cv=10, n_jobs=-1)
score_report(scores)