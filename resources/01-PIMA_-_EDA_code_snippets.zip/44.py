sns.catplot(x="age", y="onset_diabetes", kind='box', data=df, orient='h')
plt.title("age by onset_diabetes")
plt.show()
