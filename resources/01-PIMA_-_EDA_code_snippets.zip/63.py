pipeline = Pipeline([
    ( 'imp', impute.SimpleImputer(strategy='mean') ),
    ( 'model', LogisticRegression() )
]) 

X, y  = df[features].values, df.onset_diabetes.values
print(X.shape)

scores = cross_val_score(pipeline, X, y, cv=10, n_jobs=-1)
score_report(scores)