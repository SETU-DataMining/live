sns.catplot(x="bmi", y="onset_diabetes", kind='box', data=df, orient='h')
plt.title("bmi by onset_diabetes")
plt.show()
