names = ['times_pregnant', 'plasma_glucose_concentration', 'diastolic_blood_pressure', 
         'triceps_thickness', 'serum_insulin', 'bmi', 'pedigree_function', 'age', 'onset_diabetes']

df = pd.read_csv("data/pima-indians-diabetes.data.csv", names=names)
print(df.shape)
df.head(10)