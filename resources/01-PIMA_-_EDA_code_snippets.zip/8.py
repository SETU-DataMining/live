df.onset_diabetes = pd.Categorical(df.onset_diabetes)
df.onset_diabetes.value_counts(dropna=False)