sns.catplot(x="triceps_thickness", y="onset_diabetes", kind='box', data=df, orient='h')
plt.title("triceps_thickness by onset_diabetes")
plt.show()
