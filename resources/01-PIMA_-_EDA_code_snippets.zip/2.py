def score_report(scores):
    return f"Mean of {len(scores)} CV scores (accuracy) is {scores.mean():.1%} (±{scores.std():.1%})."