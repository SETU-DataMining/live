sns.countplot(x="times_pregnant", data=df)
plt.title("Times pregnant")
plt.show()
