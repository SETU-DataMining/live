sns.catplot(x="diastolic_blood_pressure", y="onset_diabetes", kind='box', data=df, orient='h')
plt.title("diastolic_blood_pressure by onset_diabetes")
plt.show()
