sns.catplot(x="times_pregnant", y="onset_diabetes", kind='box', data=df, orient="h")
plt.title("times_pregnant by onset_diabetes")
plt.show()
