sns.catplot(x="pedigree_function", y="onset_diabetes", kind='box', data=df, orient='h')
plt.title("pedigree_function by onset_diabetes")
plt.show()
