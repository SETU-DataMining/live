from kmodes.kmodes import KModes
import pandas as pd
import numpy as np