# Can also see how new items would be assigned to the given clusters
unseenGrades = [['A','B','A','C','B'], ['C','A','B','B','A']]
clusters=fittedModel.predict(unseenGrades)
print("Allocation of new students to existing clusters")
print(clusters)