# Show how data has been assigned to clusters, given the fitted centroids
clusters = fittedModel.predict(data)
print("Allocation of students to clusters")
print(clusters)