# Fit the data and display the resulting centroids
fittedModel=model.fit(data)
print("Cluster centroids - archetypal student grades")
print(fittedModel.cluster_centroids_)