# n_init=4 means rerun with 4 random starts, take the overall best
model=KModes(n_clusters=3, random_state=42, n_init=4)