# Using the transformed `Gender` as our model feature, fit the target `y`
model.fit(X[['Gender']], y)
[model.intercept_, model.coef_]