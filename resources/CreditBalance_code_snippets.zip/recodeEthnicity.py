ethnicityIndicators = pd.get_dummies(X['Ethnicity'])
# Add the dummy numeric-valued Ethnicity columns
# Remove the original categorical-valued Ethnicity column 
X = X.join(ethnicityIndicators)
X.drop(['Ethnicity'], axis=1, inplace=True)