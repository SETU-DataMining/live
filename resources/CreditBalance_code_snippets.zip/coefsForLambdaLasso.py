fig, ax = plt.subplots()

ax.set_title("Lasso Regularisation")
ax.set_xlabel("lambda")
ax.set_ylabel("standardised coefficients")
styles=['-','--','-.',':']

ax.set_xscale("log")

chosenFeatures = {"Income", "Rating", "Student"}
for i in range(0,12):
  s = styles[i % len(styles)]
  if features[i] in chosenFeatures:
    ax.plot(lambdas, coefficients[i], label=features[i], linestyle=s)
  else:
    ax.plot(lambdas, coefficients[i])

ax.legend(loc='best')
resFig = "res/lasso.pdf"
fig.savefig(resFig)