def parseToDF(foundFeatures, scoreHistory):
  scoreList = []
  for feature in foundFeatures:
    scoreDS = scoreHistory[feature]
    fitTime = np.mean(scoreDS["fit_time"])
    scoreTime = np.mean(scoreDS["score_time"])
    testNegMSE = (np.min(scoreDS["test_neg_mean_squared_error"]), np.max(scoreDS["test_neg_mean_squared_error"]))
    trainNegMSE = (np.min(scoreDS["train_neg_mean_squared_error"]), np.max(scoreDS["train_neg_mean_squared_error"]))
    testR2 = (np.min(scoreDS["test_r2"]), np.max(scoreDS["test_r2"]))
    trainR2 = (np.min(scoreDS["train_r2"]), np.max(scoreDS["train_r2"]))
    record = {'feature': feature, 'fit_time': fitTime, 'score_time': scoreTime,
              'test_neg_mean_squared_error': testNegMSE, 'train_neg_mean_squared_error': trainNegMSE,
              'test_r2': testR2, 'train_r2': trainR2}
    scoreList.append(record)
  
  scoresDf = pd.DataFrame.from_dict(scoreList)
  return scoresDf