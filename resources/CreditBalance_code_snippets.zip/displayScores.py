scoresDf = deriveScoresDf(X)
display(scoresDf)