def prioritiseFeatures(X):
  nP = X.shape[1]
  scoreHistory = dict()
  foundFeatures = list()

  for i in range(nP): # loop over all columns (features) in X
    score, bestFeatureFound, metricsForAddedFeature = findNextBestFeature(X, foundFeatures)
    foundFeatures.append(bestFeatureFound)
    scoreHistory[bestFeatureFound] = metricsForAddedFeature

  return foundFeatures, scoreHistory