# Note that we allow all hyperparameters to take their default values
model = linear_model.LinearRegression()