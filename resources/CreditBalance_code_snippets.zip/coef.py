model.fit(scaledX, y)
features = scaledX.columns
coef = pd.Series(model.coef_,features).sort_values()
coef