def deriveScoresDf(X):
  foundFeatures, scoreHistory = prioritiseFeatures(X)
  scoresDf = parseToDF(foundFeatures, scoreHistory)
  return scoresDf