import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn import linear_model
from sklearn.model_selection import cross_validate
import os

# If the `res/` directory does not exist, create it
if not os.path.exists('res'):
    os.makedirs('res')

dataFile = "data/Credit.csv"
data = pd.read_csv(dataFile, index_col=0) 

data.shape