from sklearn.model_selection import cross_val_score, KFold

lambdas = np.linspace(500,0.01,num=50) # Step 1
scoresCV = []
for l in lambdas:
  lassoReg = Lasso(alpha=l)
  lassoReg.fit(scaledX, y)    
  
  scoreCV = cross_val_score(lassoReg, scaledX, y, scoring='neg_mean_squared_error', 
                            cv=KFold(n_splits=10, shuffle=True, random_state=1))
  scoresCV.append(np.mean(scoreCV))
# Step 2 complete