from sklearn.linear_model import Ridge

# assign lambda (or alpha as is used in Ridge())
ridgeReg = Ridge(alpha=50)

# Now compute the ridge regression using X, the full matrix of features, and y
ridgeReg.fit(scaledX, y)

ridgeReg.score(scaledX, y)