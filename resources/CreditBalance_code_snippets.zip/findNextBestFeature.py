def findNextBestFeature(X,foundFeatures):
  nP = X.shape[1] # number of columns in X
  allFeatures = list(X) # See https://stackoverflow.com/a/19483025
  featuresToSearch = set(allFeatures) - set(foundFeatures)
  maxScore = -np.inf # can usually do better than this!
  for feature in featuresToSearch: # loop over all remaining columns (features) in X
    trialFeatures = set(foundFeatures)
    trialFeatures.add(feature) # Add this feature to the existing features
    XcolSubset = X.loc[:,list(trialFeatures)] # all rows and just the trial features
    scores = cross_validate(model, XcolSubset, y, cv=5, scoring=metric, return_train_score=True)
    score = np.mean(scores['test_neg_mean_squared_error'])
    trialFeatures.remove(feature) # remove the current feature from the trialFeatures, to be ready for the next candidate feature
    if score > maxScore: # identify the largest score and its associated feature
      maxScore = score
      metricsForAddedFeature = scores
      bestFeatureFound = feature
  trialFeatures.add(bestFeatureFound)
  #print(f"Selected {bestFeatureFound} so current features are {trialFeatures} with score {score} and the following metrics")

  return maxScore, bestFeatureFound, metricsForAddedFeature