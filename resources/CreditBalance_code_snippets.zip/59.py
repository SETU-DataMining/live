from sklearn.linear_model import LassoCV

lassoCV = LassoCV()
lassoCV.fit(scaledX, y)

lassoCV.alpha_