lassoReg = Lasso(lassoCV.alpha_)
lassoReg.fit(scaledX, y)
lassoReg.score(scaledX, y)