fig, ax = plt.subplots()

plt.title("Ridge regularisation")
plt.xlabel("lambda")
plt.ylabel("standardised coefficients")
styles=['-','--','-.',':']

labels = ['0.01','','1','', '100','', '1e4','']
ax.set_xticklabels(labels) # custom x labels

chosenPredictors = {"Income", "Rating", "Student"}
for i in range(0,nP):
    s = styles[i % len(styles)]
    if predictors[i] in chosenPredictors:
        plt.plot(coefficients[i], label=predictors[i], linestyle=s)
    else:
        plt.plot(coefficients[i])

plt.legend(loc='best')
resFig = "res/ridge.pdf"
plt.savefig(resFig)