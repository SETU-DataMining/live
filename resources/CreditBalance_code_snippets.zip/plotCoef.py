fig = coef.plot(kind='bar', title="Model coefficients")
resFig = "res/coeffs.pdf"
plt.savefig(resFig)