fig, ax = plt.subplots()

ax.set_title("Lambda tuning for Lasso Regularisation")
ax.set_xlabel("lambda")
ax.set_ylabel("Cross-Validation error (MSE)")

ax.plot(lambdas,scoresCV)
resFig = "res/lambdaLassoCV.pdf"
fig.savefig(resFig)