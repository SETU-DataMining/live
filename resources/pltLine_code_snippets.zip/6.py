ax2.plot(x, y)
ax2.scatter(x3,y3,color="orange")
ax2.set_title("Fitting a line to 3 collinear points")