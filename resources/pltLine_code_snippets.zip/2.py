# Just plot a normal line plot consisting of the two desired points
p1 = [0,3]
p2 = [1,-2]
p3 = [0.2,2]
p4 = [0.2,1.5]
p5 = [0.8,-0.5]