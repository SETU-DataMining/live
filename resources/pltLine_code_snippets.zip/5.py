ax1.plot(x, y)
ax1.scatter(x,y,color="orange")
ax1.set_title("Fitting a line to 2 points")