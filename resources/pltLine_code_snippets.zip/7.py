ax3.plot(x, y)
ax3.scatter(x4,y4,color="orange")
ax3.set_title("Fitting a line to 4 non-collinear points")