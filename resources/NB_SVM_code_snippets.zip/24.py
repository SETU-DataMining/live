from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC

# Import the slearn utility to compare algorithms
from sklearn import model_selection

# Prepare an array with the 2 algorithms
models = []
models.append(('NB', GaussianNB()))
models.append(('SVC', SVC(gamma='auto')))

# Prepare the configuration to run the test
seed = 42
results = []
names = []
nSplits = 10