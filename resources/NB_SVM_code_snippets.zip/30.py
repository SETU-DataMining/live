# Import scikit-learn metrics module for accuracy calculation
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report

def showDiagnostics(y, y_pred):
  # Model Accuracy, how often is the classifier correct?
  print("Accuracy:",accuracy_score(y, y_pred))
  print("Confusion Matrix:")
  print(confusion_matrix(y, y_pred))
  print("Classification Report:")
  print(classification_report(y, y_pred, digits=3))

