corr = pimaDf.corr()
corr