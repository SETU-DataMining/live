for c in ["Season", "Size", "Speed"]:
    df[c] = df[c].astype('category')