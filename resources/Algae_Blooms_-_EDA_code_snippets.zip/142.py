sns.boxplot(x="Size", y="a1", data=df, color="lightblue")
plt.show()