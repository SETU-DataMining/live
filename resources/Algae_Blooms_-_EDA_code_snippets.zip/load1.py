df = pd.read_table('data/analysis.txt')
print(df.shape)
df.head()