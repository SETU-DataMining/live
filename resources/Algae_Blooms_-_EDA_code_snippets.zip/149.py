noise = np.random.normal(size=10000)
sns.histplot(noise, kde=True, stat='density')
plt.show()