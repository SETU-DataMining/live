sns.catplot(x="Speed", y="a1", data=df, kind='point')
plt.show()