df.Season = df.Season.astype('category')
df.Size = df.Size.astype('category')
df.Speed = df.Speed.astype('category')