sns.histplot(x='mean_Chlor', data=df)
plt.show()