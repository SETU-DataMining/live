sns.boxplot(x='max_pH', data=df)
plt.show()