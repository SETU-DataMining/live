sns.countplot(x="Speed", data=df)
plt.show()