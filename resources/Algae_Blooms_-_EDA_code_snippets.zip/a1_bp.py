sns.boxplot(x="a1", data=df)
plt.show()