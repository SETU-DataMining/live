sns.boxplot(x='mean_Chlor', data=df)
plt.show()