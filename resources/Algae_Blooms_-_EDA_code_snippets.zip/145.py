sns.catplot(data=df,x="Size", y="a4", kind="bar")
plt.show()