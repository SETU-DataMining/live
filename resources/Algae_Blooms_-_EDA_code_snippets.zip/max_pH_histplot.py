sns.histplot(x='max_pH', data=df)
plt.show()