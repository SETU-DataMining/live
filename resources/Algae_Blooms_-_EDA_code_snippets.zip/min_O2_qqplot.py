pg.qqplot(df.min_O2)
plt.title('Normal QQ plot of maximum pH')
plt.show()