plt.figure(figsize=(8,1))
sns.boxplot(x="a1", data=df)
plt.xlabel("")
plt.show()