df = pd.read_table('data/analysis.txt', sep='\s+', header=None)
print(df.shape)
df.head()