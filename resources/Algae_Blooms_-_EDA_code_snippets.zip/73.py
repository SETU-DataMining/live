sns.kdeplot(x="a1", hue="Season", fill=True, data=df)
plt.show()