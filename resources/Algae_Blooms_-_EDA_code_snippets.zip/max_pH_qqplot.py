pg.qqplot(df.max_pH)
plt.title('Normal QQ plot of maximum pH')
plt.show()