sns.boxplot(x="a1", y="Season", data=df)
plt.show()