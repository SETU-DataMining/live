fig, axs = plt.subplots(1, 7, figsize=(28,6))
for k, c in enumerate(df.columns[11:18]):
    pg.qqplot(df[c], ax=axs[k])
    axs[k].set_xlabel(c)
plt.show()