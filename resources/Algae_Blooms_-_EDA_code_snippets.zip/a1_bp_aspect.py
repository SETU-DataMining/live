plt.figure(figsize=(8,6))
sns.boxplot(x="a1", data=df)
plt.show()