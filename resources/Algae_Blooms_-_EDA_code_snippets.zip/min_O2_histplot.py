sns.histplot(x='min_O2', data=df)
plt.show()