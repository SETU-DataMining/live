plt.figure(figsize=(8,6))
sns.boxplot(x="a1", y="Speed", hue="Size", data=df)
plt.show()