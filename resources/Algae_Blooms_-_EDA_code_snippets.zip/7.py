# used when generating images for slides
sns.set_context('talk')