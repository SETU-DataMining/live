sns.catplot(x="Season", y="a1", data=df, kind='strip')
plt.show()