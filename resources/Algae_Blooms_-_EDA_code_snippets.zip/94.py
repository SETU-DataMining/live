sns.kdeplot(x="a1", hue="Speed", fill=True, data=df)
plt.show()