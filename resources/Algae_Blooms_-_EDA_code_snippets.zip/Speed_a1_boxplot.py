sns.boxplot(x="a1", y="Speed", data=df)
plt.show()