sns.lmplot(x="max_pH", y="a1", data=df)
plt.show()