fig, axs = plt.subplots(1, 8, figsize=(24,6))
for k, c in enumerate(df.columns[3:11]):
    sns.histplot(data=df, x=c, color="lightblue", ax=axs[k])
    axs[k].set_xlabel(c)
plt.show()