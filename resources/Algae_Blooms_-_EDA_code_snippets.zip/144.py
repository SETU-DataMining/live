#from pandas_profiling import ProfileReport
#if False:
#    profile = ProfileReport(df, title="Algae Blooms Report", html={"style": {"full_width": True}})
#    profile