sns.catplot(x="Size", y="a1", data=df, kind='bar')
plt.show()