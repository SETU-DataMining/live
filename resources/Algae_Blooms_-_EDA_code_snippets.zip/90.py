sns.kdeplot(x="a4", hue="Size", fill=True, data=df)
plt.show()
