df = pd.read_table('data/analysis.txt', header=None)
print(df.shape)
df.head()