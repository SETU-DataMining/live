df.Season = pd.Categorical(df.Season, ordered=True, categories=["spring", "summer", "autumn", "winter"])
df.Size = pd.Categorical(df.Size, ordered=True, categories=["small", "medium", "large"])
df.Speed = pd.Categorical(df.Speed, ordered=True, categories=["low", "medium", "high"])