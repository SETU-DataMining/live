plt.figure(figsize=(8,6))
sns.boxplot(x="a1", y="Size", hue="Speed", data=df)
plt.show()