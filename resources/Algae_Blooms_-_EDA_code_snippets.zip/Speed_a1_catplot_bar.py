sns.catplot(x="Speed", y="a1", data=df, kind='bar')
plt.show()