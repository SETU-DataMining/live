# not needed any more ? (due to pdf capture in notebook_exporter)
sns.catplot(x="Size", y="a4", data=df, kind='bar', aspect=4/3);
plt.savefig("pic/Size_a4_catplot_bar.pdf", bbox_inches="tight")