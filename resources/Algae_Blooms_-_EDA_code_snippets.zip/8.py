import os
for d in ['data', 'output', 'pic']:
    if not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)