if False:
    import dtale
    dtale.show(df, open_browser=True)