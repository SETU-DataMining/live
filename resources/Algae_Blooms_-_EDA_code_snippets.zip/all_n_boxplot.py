fig, axs = plt.subplots(1, 8, figsize=(24,6))
for k, c in enumerate(df.columns[3:11]):
    sns.boxplot(data=df, y=c, color="lightblue", ax=axs[k])
    axs[k].set_xlabel(c)
plt.show()