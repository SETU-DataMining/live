sns.countplot(x="Season", data=df)
plt.show()