pg.qqplot(df.mean_Chlor)
plt.title('Normal QQ plot of maximum pH')
plt.show()