plt.figure(figsize=(4,6))
sns.histplot(x="a7", data=df)
plt.show()