speechDf = pd.read_csv('data/inaug_speeches.csv', usecols=['Name','Date','text'], encoding='latin1')
speechDf.head()