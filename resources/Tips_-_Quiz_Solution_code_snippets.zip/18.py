Q1, Q3 = df.total_bill.quantile([0.25,0.75]).values
IQR = Q3 - Q1
IQR