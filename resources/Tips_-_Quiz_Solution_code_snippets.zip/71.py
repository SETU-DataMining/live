# "male servers earn the largest percentage tips"
df.groupby('sex').percentage_tip.max()