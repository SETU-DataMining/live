# Note the reversing of the sort order - other approaches available also
claim_2 = df.groupby('sex').percentage_tip.max().sort_values(ascending=False).index[0] == 'Male'
claim_2