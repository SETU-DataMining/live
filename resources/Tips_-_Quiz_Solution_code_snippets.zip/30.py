# Step 1 - count number of bills on each day
df.day.value_counts()