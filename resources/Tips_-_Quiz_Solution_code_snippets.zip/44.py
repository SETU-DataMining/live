# and a variation to output just the required answer 
df.groupby("sex")['percentage_tip'].mean()['Male']