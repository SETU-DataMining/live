# claim 1: "female servers have higher average percentage tips"
df.groupby('sex').percentage_tip.mean()