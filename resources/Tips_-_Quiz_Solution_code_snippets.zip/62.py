# filter to rows based on the given condition (the day was Sunday)
df_tmp = df.query("day=='Sun'")

# compute probability using value_counts
df_tmp.sex.value_counts(normalize=True)['Female']