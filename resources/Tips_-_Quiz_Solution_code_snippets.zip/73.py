# Test overall statement
claim_1 and claim_2