# loc can also take a second argument representing the columns to select
df.loc[df.sex=='Male','percentage_tip'].mean()