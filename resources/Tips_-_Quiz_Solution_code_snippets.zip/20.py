Q1, Q3 = df.total_bill.quantile([0.25,0.75]).values
IQR = Q3 - Q1

left_outliers = (df.total_bill < Q1 - 1.5 * IQR).sum() 
right_outliers = (df.total_bill > Q3 + 1.5 * IQR).sum()

left_outliers + right_outliers