# store result in a boolean variable for later use 
# V2 - note the sort_values to ensure correct order
claim_1 = df.groupby('sex').percentage_tip.mean().sort_values(ascending=False).index[0] == 'Female'
claim_1