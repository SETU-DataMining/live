# Step 1,2,3 - count days that match condition by summing (remember False->0 and True->1 when conveerting to int)
(df.day.value_counts()>60).sum()