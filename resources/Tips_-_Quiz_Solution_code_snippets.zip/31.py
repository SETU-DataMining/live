# Step 1,2 - convert count to False/True based on condition >60
df.day.value_counts()>60