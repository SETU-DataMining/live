# note the sort_values to ensure correct order
df.groupby('time').tip.mean().sort_values(ascending=False).index[0]