# shape[0] represent number of rows 

df.query("sex=='Female'").shape[0] / df.shape[0]