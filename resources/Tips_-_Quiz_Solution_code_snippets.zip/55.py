# Solution 1a - filter using query/loc and compute probability
# property size returns the number of values in a variable (series/coolumn)

df.query("sex=='Female'").sex.size / df.sex.size