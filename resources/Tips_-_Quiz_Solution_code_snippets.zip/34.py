# Step 1 - create new variable to store the percentage tip
#
# NOTE that this variable is available for all subsequent questions/calculations 

df["percentage_tip"] = df.tip / df.total_bill