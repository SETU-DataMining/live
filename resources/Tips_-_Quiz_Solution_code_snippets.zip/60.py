# filter to rows based on the given condition (the day was Sunday)
df_tmp = df.query("day=='Sun'")

# compute probability = number of rows matching required condition (female) / number of rows matching given condition (sunday)
# df_tmp.shape[0] returns number of rows
(df_tmp.sex=='Female').sum() / df_tmp.shape[0]