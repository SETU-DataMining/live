plt.plot(X, y, "k.");
plt.xlim(0,1)
plt.ylim(-1,3)
plt.title(f"Noisy signal f1 ({len(X)} points, x distributed according to uniform distribution)")
plt.xlabel("x")
#plt.savefig('output/noisySignal.pdf')
plt.show()
