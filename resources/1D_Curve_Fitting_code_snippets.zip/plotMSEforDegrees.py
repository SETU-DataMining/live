fig = plt.figure()
plt.plot(mseDf.index, mseDf['train'], "r+", label='train MSE')
plt.plot(mseDf.index, mseDf['test'], "b.", label='test MSE')
plt.title(f"MSE for train and test against degree")
plt.xlabel("polynomial degree")
plt.legend()
plt.savefig(f"output/MSEforDegrees.pdf")
#=
plt.show()
