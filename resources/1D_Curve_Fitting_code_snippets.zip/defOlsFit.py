def olsFit(X_train_poly, y_train):
  # Fit a Linear Regression model to the polynomial features
  model = LinearRegression()
  model.fit(X_train_poly, y_train)
  betaPoly = model.coef_
  betaPolyRange = np.max(betaPoly)-np.min(betaPoly)
  return model, betaPoly, betaPolyRange