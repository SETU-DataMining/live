sns.displot(noise, kde=True)
plt.show()
