def plotLambdasForDegrees(rType, mseDf):
  fig = plt.figure()
  plt.plot(mseDf.index, mseDf['bestLambda'], "k.-", label='best lambda')
  plt.title(f"{rType} best lambda against degree")
  plt.xlabel("polynomial degree")
  plt.legend(frameon=True)
  plt.savefig(f"output/{rType}/lambdasForDegrees.pdf")
plt.show()
