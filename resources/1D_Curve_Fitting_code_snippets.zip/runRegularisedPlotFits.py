# See https://stackoverflow.com/a/76020741 and https://stackoverflow.com/a/67548340
data = []
for rType in ('OLS', 'regularisedLR'):
  data.append(fitPlotAndSave(X_train, y_train, X_test, y_test, maxDegree=12, rType=rType))
mseDf = pd.concat(data, axis=0, ignore_index=True)
mseDf