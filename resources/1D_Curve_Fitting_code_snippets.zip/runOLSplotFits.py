trainMSE = []
testMSE = []
coeffs = []
ranges =[]
rType = "OLS"
for degree in range(0,11):
  mseTrain, mseTest, betaPolyRange, betaPoly = fitAndPlot(rType, X_train, y_train, degree, X_test, y_test)
  #pp.savefig(fig) # fig is a global variable, as a workaround to a notebook_exporter bug
  
  trainMSE.append(mseTrain)
  testMSE.append(mseTest)
  coeffs.append(betaPoly)
  ranges.append(betaPolyRange)

mseDf = pd.DataFrame({'train': trainMSE, 'test': testMSE, 'betaPolyRange': ranges, 'betaPoly': coeffs})
#mseDf