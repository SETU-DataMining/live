def fitAndPlot(X_train, y_train, Xtest, y_test, degree, rType):
  poly, X_train_poly, X_test_poly = preparePolyFeatures(degree, X_train, y_train)
  if (rType == 'OLS'):
    model, betaPoly, betaPolyRange = olsFit(X_train_poly, y_train)
    bestLambda = 0.0
  else:
    lambdas = np.logspace(-3.0, 4.0, num=16, base=10.0)
    model, betaPoly, betaPolyRange, cvLambdaScores, bestLambda = regularisedLRFit(X_train_poly, y_train, lambdas)
  # Now use K=5-fold cross-validation to estimate the MSE of the model fit, relative to the validation data (the left-out data) 
  cv_results = cross_validate(model, X_train_poly, y_train, cv=5,
               scoring=('neg_mean_squared_error'),  return_train_score=True)
  mseCV = -1*np.mean(cv_results['test_score'])
  # For comparison, we can compute the training and test MSE scores
  mseTrain = prepMSE(model, X_train_poly, y_train)
  mseTest = prepMSE(model, X_test_poly, y_test)
  X_plot, X_plot_poly, y_plot_pred = preparePolyPoints(poly, model)
  # prepare the figure showing the fitted polynomial against the training and test data
  prepPlotFit(rType, X_train, y_train, X_test, y_test, X_plot, y_plot_pred, degree)
  return mseCV, mseTrain, mseTest, betaPolyRange, betaPoly, bestLambda