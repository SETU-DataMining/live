def preparePolyPoints(poly, model):
  # generate extra ordered points for smooth curve
  X_plot = np.linspace(0, 1, 100)
  X_plot_poly = poly.transform(X_plot.reshape(-1, 1))
  y_plot_pred = model.predict(X_plot_poly)
  return X_plot, X_plot_poly, y_plot_pred