def fitPlotAndSave(X_train, y_train, X_test, y_test, maxDegree, rType):
  cvMSE = []
  trainMSE = []
  testMSE = []
  #coeffs = []
  ranges = []
  bestLambdas = []
  for degree in range(0,maxDegree+1):
    mseCV, mseTrain, mseTest, betaPolyRange, betaPoly, bestLambda = fitAndPlot(X_train, y_train, X_test, y_test, degree, rType)
    
    cvMSE.append(mseCV)
    trainMSE.append(mseTrain)
    testMSE.append(mseTest)
    ranges.append(betaPolyRange)
    #coeffs.append(betaPoly)
    bestLambdas.append(bestLambda)
  
  degrees = list(range(0,maxDegree+1))
  rTypes = [rType] * len(degrees) 
  mseDf = pd.DataFrame({
    'rType': rTypes,
    'degree': degrees,
    'bestLambda': bestLambdas,
    'cvMSE': cvMSE,
    'train': trainMSE,
    'test': testMSE,
    'betaPolyRange': ranges
    })
  plotMSEforDegrees(rType, mseDf)
  plotCoeffsForDegrees(rType, mseDf)
  plotLambdasForDegrees(rType, mseDf)
  return mseDf