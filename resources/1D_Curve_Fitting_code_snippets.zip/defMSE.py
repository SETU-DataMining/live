def prepMSE(model, X_poly, y):
  # Compute the mean_squared_error between the actual and predicted targets
  y_pred = model.predict(X_poly)
  mseScore = mean_squared_error(y, y_pred) 
  return mseScore