mseDf = pd.concat(data, axis=0, ignore_index=True)
mseDf