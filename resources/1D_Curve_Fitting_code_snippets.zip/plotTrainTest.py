plt.scatter(X_train, y_train, color=colours[0], marker="+", label='train');
plt.scatter(X_test, y_test, color=colours[1], marker=".", label='test');
plt.title(f"Actual Noisy signal ({len(y_train)} train, {len(y_test)} test data)")
plt.xlabel("x")
plt.ylabel("y")
plt.xlim(0,1)
plt.ylim(-1,3)
plt.legend(frameon=True)
#plt.savefig('output/trainTest.pdf')
plt.show()
