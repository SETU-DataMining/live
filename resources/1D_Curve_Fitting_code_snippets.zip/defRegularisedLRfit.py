def regularisedLRFit(X_train_poly, y_train, lambdas):
  # Fit a regularised Linear Regression model to the polynomial features
  model = RidgeCV(alphas=lambdas, scoring = 'neg_mean_squared_error', store_cv_results=True)
  model.fit(X_train_poly, y_train)
  betaPoly = model.coef_
  cvScores = model.cv_results_
  bestLambda = model.alpha_
  betaPolyRange = np.max(betaPoly)-np.min(betaPoly)
  return model, betaPoly, betaPolyRange, cvScores, bestLambda