def prepPlotFit(rType, X_train, y_train, X_test, y_test, X_plot, y_plot_pred, degree):
  # prepare the figure showing the fitted polynomial against the training and test data
  # global fig
  # neded so that return is not needed from this function - otherwise run into bug in notebook_exporter
  fig = plt.figure()
  plt.scatter(X_train, y_train, color=colours[0], marker="+", label='actual (train)')
  plt.scatter(X_test, y_test, color=colours[1], marker=".", label='actual (test)')
  plt.plot(X_plot, y_plot_pred, color=colours[4], label='model')
  plt.title(f"Plot (degree={degree}) {rType} polynomial fit to Actual ({len(y_train)} training, {len(y_test)} test) points")
  plt.xlabel("x")
  plt.legend(frameon=True)
  plt.ylim(-1,3)
  plt.savefig(f'output/{rType}/trainTest{degree}.pdf')
plt.show()
plt.close()
plt.show()
