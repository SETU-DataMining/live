pg.qqplot(noise)
plt.show()
