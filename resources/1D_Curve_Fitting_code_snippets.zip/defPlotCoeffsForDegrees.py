def plotCoeffsForDegrees(rType, mseDf):
  fig = plt.figure()
  plt.plot(mseDf.index, mseDf['betaPolyRange'], "k.-", label='range beta')
  plt.title(f"{rType} Range (max-min) beta (polynomial coefficients) against degree")
  plt.xlabel("polynomial degree")
  plt.legend(frameon=True)
  plt.savefig(f"output/{rType}/coeffsForDegrees.pdf")
plt.show()
