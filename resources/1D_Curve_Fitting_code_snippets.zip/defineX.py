X = uniform.rvs(loc=0, scale=1, size=50, random_state=42)
X.sort()