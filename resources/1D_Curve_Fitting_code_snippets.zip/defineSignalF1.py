def f1(x):
  return struve(0,10*x)