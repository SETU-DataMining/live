import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
plt.style.use("seaborn-v0_8-whitegrid")

import seaborn as sns
import pingouin as pg

from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_validate

from sklearn.linear_model import LinearRegression
from sklearn.linear_model import RidgeCV

from sklearn.preprocessing import PolynomialFeatures

from sklearn.metrics import mean_squared_error

from scipy.special import struve

from scipy.stats import norm, uniform

# The following can be used to combine pdfs into 1
#from matplotlib.backends.backend_pdf import PdfPages
#
# See https://stackoverflow.com/a/11329151
#pp = PdfPages('output/combined.pdf')
#pp.savefig(fig) # add figure using its fig handle

colours = sns.color_palette('colorblind')