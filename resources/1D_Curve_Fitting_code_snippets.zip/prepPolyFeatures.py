def preparePolyFeatures(degree, X_train, y_train):
  poly = PolynomialFeatures(degree)
  # fit = train = determine optimal parameters using the train dataset only
  poly.fit(X_train.reshape(-1, 1))
  # transform = apply transformation to both train and test
  X_train_poly = poly.transform(X_train.reshape(-1, 1))
  X_test_poly = poly.transform(X_test.reshape(-1, 1))
  return poly, X_train_poly, X_test_poly