fig, ax = plt.subplots(nrows=1,ncols=3, figsize=(12,2))
for k, b in enumerate([5,20,50]):
    df.total_bill.plot(kind='hist', bins=b, ax=ax[k]);
    ax[k].set_title(f"bins {b}")