df.total_bill.plot(kind='box', vert=False)
plt.yticks(rotation=90);