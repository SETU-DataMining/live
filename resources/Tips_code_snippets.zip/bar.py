df.day.value_counts().plot(kind='bar')
plt.xticks(rotation=0);