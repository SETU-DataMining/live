# See https://stackoverflow.com/a/70597369/1988855
df['Date'] = np.where(df['Date'].dt.year > 2000, df['Date'] - pd.offsets.DateOffset(years=100), df['Date'])
df.info()