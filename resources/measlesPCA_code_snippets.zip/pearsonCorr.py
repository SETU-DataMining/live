pearsonCorr = df.corr(numeric_only=True)
pearsonCorr