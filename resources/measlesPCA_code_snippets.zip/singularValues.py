sv = dict(zip(x, pca.singular_values_))
sv