kendallCorr = df.corr(method='kendall',numeric_only=True)
kendallCorr