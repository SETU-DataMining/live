df = df.loc[df.isna().sum(axis=1)<1].copy()
df.info()