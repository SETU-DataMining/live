# See https://stackoverflow.com/a/10154763
fig.savefig('res/evr_sv.pdf', bbox_extra_artists=(ylabel1,ylabel2,title), bbox_inches='tight')
plt.show()
