spearmanCorr = df.corr(method='spearman',numeric_only=True)
spearmanCorr