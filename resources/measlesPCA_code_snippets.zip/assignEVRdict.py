# See https://sparkbyexamples.com/pandas/pandas-get-column-names/
cities = df._get_numeric_data().columns.values.tolist()
pca = PCA()
pca.fit(df[cities])