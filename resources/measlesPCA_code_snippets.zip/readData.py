# Data source: https://ms.mcmaster.ca/~bolker/measdata/ewcitmeas.dat
df0 = pd.read_table('data/ewcitmeas.dat', delimiter='\s+', na_values='*', header=0)