cmap = sns.diverging_palette(230, 20, as_cmap=True)
hm = sns.heatmap(kendallCorr, square=True, vmin=-1, vmax=1, cmap=cmap)
fig = hm.get_figure()
plt.savefig('res/kendallCorrHeatmap.pdf')