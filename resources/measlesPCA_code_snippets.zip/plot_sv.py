y2 = list(sv.values())
ylabelT2 = "Singular Values"
color2 = cs.ibm5col['orange']
ax2.plot(x, y2, 'o-', color=color2, label=ylabelT2)
ylabel2 = ax2.set_ylabel(ylabelT2, color=color2, fontsize=16)