y1 = list(evr.values())
ylabelT1 = "Explained Variance Ratio"
color1 = cs.ibm5col['trueBlue']
ax1.plot(x, y1, 'o-', color=color1, label=ylabelT1)
ylabel1 = ax1.set_ylabel(ylabelT1, color=color1, fontsize=16)