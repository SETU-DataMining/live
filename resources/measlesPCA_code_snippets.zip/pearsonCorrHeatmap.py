cmap = sns.diverging_palette(230, 20, as_cmap=True)
hm = sns.heatmap(pearsonCorr, square=True, vmin=-1, vmax=1, cmap=cmap)
# See https://stackoverflow.com/a/47765118/1988855
fig = hm.get_figure()
fig.savefig('res/pearsonCorrHeatmap.pdf')