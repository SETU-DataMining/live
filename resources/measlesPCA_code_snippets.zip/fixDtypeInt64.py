df = df.astype({'London': 'int64', 'Bristol': 'int64', 'Liverpool': 'int64', 'Birmingham': 'int64'})
df.info()
df.head(11)