# See https://stackoverflow.com/a/49718899/1988855
df0.insert(0,'Date',pd.to_datetime(df0[['#DD','MM','YY']].astype(str).apply(' '.join, 1), format='%d %m %y'))