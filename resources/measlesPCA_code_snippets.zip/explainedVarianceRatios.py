# See https://www.atatus.com/blog/python-converting-lsts-to-dictionaries/
x = range(1, len(pca.explained_variance_ratio_)+1)
evr = dict(zip(x, pca.explained_variance_ratio_))
evr