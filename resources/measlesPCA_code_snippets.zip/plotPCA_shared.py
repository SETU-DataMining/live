# See https://stackoverflow.com/a/55654661/1988855
fig, ax1 = plt.subplots()
# See https://stackoverflow.com/a/10154763/1988855
ax2 = ax1.twinx()
ax1.set_xlabel('Number of Principal Components')
title=ax1.set_title("Explained Variance Ratio and related Singular Values", weight="bold")