resFig = "res/simpleModel2_influence.pdf"
fig = sm.graphics.influence_plot(simpleModel2, criterion="cooks")
fig.tight_layout(pad=1.0)
fig.savefig(resFig)