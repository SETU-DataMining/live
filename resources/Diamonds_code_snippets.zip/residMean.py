import numpy as np
residuals = simpleModel.resid
residMean = np.mean(residuals)
resid2Mean = np.mean(residuals2)
[residMean, resid2Mean]