newDiamonds = sm.add_constant([0.16, 0.27, 0.34]) # add the intecept for each of the 3 weights
simpleModel.predict(newDiamonds)