fig = plt.figure()
ax = fig.add_subplot(1,1,1)
resFig = "res/diamonds.pdf"

ax.scatter(diamondData.carats, diamondData.price)
fig.suptitle("Relation between diamonds' price and weight")
ax.set_ylabel('Price [SIN $]')
ax.set_xlabel('Weight [carat]')
ax.grid(True)
plt.savefig(resFig)