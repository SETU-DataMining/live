residuals2 = simpleModel2.resid
fig = plt.figure()
# We plot the residuals of the new model fitted to the training data
ax = fig.add_subplot(111, projection='3d')
resFig = "res/residuals2.pdf"

ax.scatter(diamondData2.carats, diamondData2.quality, residuals2)
fig.suptitle("Residuals plotted against weight and quality")
ax.set_zlabel('Actual - Prediced Price [SIN $]')
ax.set_ylabel('Quality [ratio]')
ax.set_xlabel('Weight [carat]')
ax.grid(True)
plt.savefig(resFig)