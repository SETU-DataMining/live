X = sm.add_constant(diamondData.carats)
X.head()