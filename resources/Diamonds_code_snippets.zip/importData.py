import pandas as pd
dataFile = "data/diamond.dat.txt"
import os
if not os.path.exists('res'):
    os.makedirs('res')