covMatrixForPredictedPts = np.matmul(x_1, np.matmul(np.array(covMatrixForParams), x_1.T))
varPredictedPts = np.diagonal(covMatrixForPredictedPts)
varPredictedLine = simpleModel.mse_resid
totVarPredicted = varPredictedLine + varPredictedPts
totSePredicted = np.sqrt(totVarPredicted)
totSePredicted