y = diamondData.price
n = len(y)
p = 2
df = n-p
MSE = sum(residuals**2) / df
RMSE = np.sqrt(MSE)
RMSE