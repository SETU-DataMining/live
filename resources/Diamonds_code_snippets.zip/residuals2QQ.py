resFig = "res/residuals2qq.pdf"
fig = sm.qqplot(residuals2, fit=True, line = '45')
fig.savefig(resFig)