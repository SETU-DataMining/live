# We can also plot the model prediction against individual features
resFig = "res/simpleModel_carats_4plot.pdf"
fig = sm.graphics.plot_regress_exog(simpleModel, "carats")
fig.tight_layout(pad=1.0)
fig.savefig(resFig)