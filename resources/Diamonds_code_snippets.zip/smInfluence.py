# Statsmodels provides an `influence` plot that we can use to check the influence of a each observation
# This can help to diagnose problems with specific observations, but can become unwieldy if there are many
# training set observations.
resFig = "res/simpleModel_influence.pdf"
fig = sm.graphics.influence_plot(simpleModel, criterion="cooks")
fig.tight_layout(pad=1.0)
fig.savefig(resFig)