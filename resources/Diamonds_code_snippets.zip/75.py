covMatrixForParams = simpleModel.cov_params()
covMatrixForParams