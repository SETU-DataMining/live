newDiamond = [1, 0.2] # remember to add the intercept term (1)!
simpleModel.predict(newDiamond)