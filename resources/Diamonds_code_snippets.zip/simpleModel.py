simpleModel = sm.OLS(diamondData.price, X).fit()
simpleModel.params  # here are the beta coefficients (intercept and slope of the linear regression line)