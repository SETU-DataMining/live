predicted = simpleModel.fittedvalues
x_1 = simpleModel.model.exog # this is the observation matrix used to fit the data