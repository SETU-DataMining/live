from scipy.stats import t
alpha=0.05 # confidence interval for two-sided hypothesis
qt = 1 - (alpha/2)  # (0.25, 0.975) for a 2-sided 95% probability

tppf = t.isf(alpha/2.0, simpleModel.df_resid)