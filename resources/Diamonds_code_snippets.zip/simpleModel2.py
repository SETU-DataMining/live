# Now we can derive the new features dataframe `X2` and apply OLS 
X2 = sm.add_constant(diamondData2[["carats","quality"]])
simpleModel2 = sm.OLS(diamondData2.price, X2).fit()
simpleModel2.params