# Create a (cloned) copy of our diamondData dataframe.
# That way we can make changes to the clone, without affecting the original diamondData dataframe.
diamondData2 = diamondData.copy()

# We insert the new "quality" column
diamondData2.insert(1,'quality',residuals,False)

# We then proceed to scale the column using scikit-learn's `MinMaxScaler`, which scales the data in the quality column
# so that the most negative residual(s) become -1 and the most positive residual(s) become 1, with the remaining residuals
# ending up somewhere in between the two extremes.
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
diamondData2[['quality']] = scaler.fit_transform(diamondData2[["quality"]]).round(1)
diamondData2.head()