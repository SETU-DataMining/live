interval_u = predicted + tppf * totSePredicted
interval_l = predicted - tppf * totSePredicted