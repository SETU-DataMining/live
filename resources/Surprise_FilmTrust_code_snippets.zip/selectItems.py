# Get a list of all movie ids
iids = ratings['iid'].unique()
# Get a list of iids that user '50' has rated
iidsRankedByUid50 = ratings.loc[ratings['uid']==50, 'iid']
# Remove the iids that user 50 has rated from all the list of movie ids
# Note the use of numpy's set difference function
iids_to_predict = np.setdiff1d(iids, iidsRankedByUid50)