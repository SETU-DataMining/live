testset = [[50, iid, -1] for iid in iids_to_predict]
predictions = alg.test(testset)