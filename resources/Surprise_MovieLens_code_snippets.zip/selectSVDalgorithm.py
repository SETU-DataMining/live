# Use the SVD algorithm to estimate missing ratings
algo = SVD()