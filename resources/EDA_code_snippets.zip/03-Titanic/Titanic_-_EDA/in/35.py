df = pd.read_csv("train.csv")
df.columns