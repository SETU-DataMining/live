plt.figure(figsize=(6,2));
sns.boxplot(x="x", data=df2)
plt.show()
