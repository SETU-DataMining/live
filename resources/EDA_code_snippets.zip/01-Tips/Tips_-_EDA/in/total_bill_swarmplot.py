ax = sns.swarmplot(data=df,  x="total_bill", color=".25")
plt.show()
