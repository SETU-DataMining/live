sns.countplot(x="sex", hue="smoker", data=df)
plt.show()
