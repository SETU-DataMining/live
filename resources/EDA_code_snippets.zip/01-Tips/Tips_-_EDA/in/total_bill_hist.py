df.total_bill.plot(kind="hist")
plt.show()
