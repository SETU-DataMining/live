plt.figure(figsize=(6,2));
sns.countplot(y="size", data=df)
plt.show()
