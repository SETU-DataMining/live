sns.ecdfplot(data=df, x="total_bill")
plt.show()
