df.total_bill.plot(kind="box", vert=False, figsize=(6,2))
plt.yticks(rotation=90)
plt.show()
