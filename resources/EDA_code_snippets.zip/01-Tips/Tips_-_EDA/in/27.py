f, (a0, a1) = plt.subplots(2,1, gridspec_kw={'height_ratios': [3, 1]}, figsize=(6,6))

df.total_bill.plot(kind="hist", ax=a0)
df.total_bill.plot(kind="box", vert=False, ax=a1)
plt.yticks(rotation=90)
plt.show()
