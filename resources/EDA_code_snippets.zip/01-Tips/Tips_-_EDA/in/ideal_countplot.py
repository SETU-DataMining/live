sns.countplot(x="my ideal category", data=df2);
plt.tight_layout()
plt.show()
