ax = sns.violinplot(data=df, x="total_bill", color=".25")
plt.show()
