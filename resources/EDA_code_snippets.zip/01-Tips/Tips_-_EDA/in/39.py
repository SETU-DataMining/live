sns.catplot(y="size", data=df, kind="count")
plt.show()
