sns.displot(data=df, x="total_bill", kde=True, rug=True)
plt.show()
