sns.histplot(data=df, x="total_bill", kde=True)
plt.show()
