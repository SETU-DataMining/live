#from pandas_profiling import ProfileReport
#profile = ProfileReport(df, title="Tips Report", html={"style": {"full_width": True}})
#profile