sns.jointplot(x="total_bill", y="tip", data=df, height=5)
plt.show()
