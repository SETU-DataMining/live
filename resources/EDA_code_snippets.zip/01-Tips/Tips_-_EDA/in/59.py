sns.catplot(x="sex", y="total_bill", data=df, kind="point")
plt.axhline(df[df.sex=='Female']["total_bill"].mean())
plt.axhline(df[df.sex=='Female']["total_bill"].mean() + 1.96*df[df.sex=='Female']["total_bill"].std()/np.sqrt(sum(df.sex=='Female')))
plt.axhline(df[df.sex=='Female']["total_bill"].mean() - 1.96*df[df.sex=='Female']["total_bill"].std()/np.sqrt(sum(df.sex=='Female')))

# plt.axhline(df[df.sex=='Male']["total_bill"].mean(), color='r')
# plt.axhline(df[df.sex=='Male']["total_bill"].mean() + 1.96*df[df.sex=='Male']["total_bill"].std()/np.sqrt(sum(df.sex=='Male')), color='r')
# plt.axhline(df[df.sex=='Male']["total_bill"].mean() - 1.96*df[df.sex=='Male']["total_bill"].std()/np.sqrt(sum(df.sex=='Male')), color='r')
plt.show()
