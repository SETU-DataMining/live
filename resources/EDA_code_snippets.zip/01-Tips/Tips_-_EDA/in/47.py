from scipy import stats
rv = stats.uniform()
data=rv.rvs(size=10_000)
sns.displot(data, kde=True, bins=30)
plt.show()
