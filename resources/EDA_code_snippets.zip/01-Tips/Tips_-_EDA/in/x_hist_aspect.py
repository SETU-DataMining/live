plt.figure(figsize=(6,2));
sns.histplot(x="x", data=df2, kde=True)
plt.show()
