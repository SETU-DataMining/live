ax = sns.boxplot(data=df, x="total_bill")
plt.show()
