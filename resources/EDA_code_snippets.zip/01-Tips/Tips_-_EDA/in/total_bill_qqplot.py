pg.qqplot(df.total_bill)
plt.show()
