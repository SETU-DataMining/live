pd.crosstab(columns=df.sex, index=df.smoker, margins=True, 
    normalize='columns').style.format("{:.2%}").background_gradient(cmap='summer_r')