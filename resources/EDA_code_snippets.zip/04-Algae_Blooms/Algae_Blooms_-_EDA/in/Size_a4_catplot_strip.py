sns.catplot(x="Size", y="a4", data=df, kind='strip')
plt.show()
