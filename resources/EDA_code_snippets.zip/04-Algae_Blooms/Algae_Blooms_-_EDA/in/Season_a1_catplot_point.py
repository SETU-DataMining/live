sns.catplot(x="Season", y="a1", data=df, kind='point')
plt.show()
