plt.plot(xs,ys)
plt.show()
