plt.plot(x,y,'.')
plt.axhline(y=0, xmin=0, xmax=n, color='gray', linestyle='dotted')
plt.savefig("res/randomResiduals.pdf", format="pdf", bbox_inches="tight")
plt.show()
