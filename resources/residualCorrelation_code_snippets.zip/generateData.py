mu, sigma = 0, 1
n = 60
x = np.arange(0,n)
seed = 42
y = np.random.default_rng(seed).normal(mu, sigma, n)/4
coef = np.array([0, 1, -2, 3, -4, 5, -6, -7, 8, -9, 10])/15
domain = [-1, 1]
(xs, ys) = np.polynomial.chebyshev.Chebyshev(coef, domain=domain).linspace(n,[0,1])
ys = ys - np.mean(ys)