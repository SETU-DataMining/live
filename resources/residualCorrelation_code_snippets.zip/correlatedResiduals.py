yc = y + ys
plt.plot(x, yc, '.')
plt.axhline(y=0, xmin=0, xmax=n, color='gray', linestyle='dotted')
plt.savefig("res/correlatedResiduals.pdf", format="pdf", bbox_inches="tight")
plt.show