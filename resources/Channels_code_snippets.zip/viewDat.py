featureNames = df.columns[:3]
targetName = df.columns[3]
X3 = df[featureNames]
y = df[targetName]
df.head()