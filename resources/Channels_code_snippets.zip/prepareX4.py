X4 = X3.copy()
X4["TV:Radio"] = X4['TV'] * X4['Radio']
scaler = MinMaxScaler()
scaler.fit(X4)
X4scaled = scaler.transform(X4)