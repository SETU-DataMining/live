df = pd.read_csv('data/Advertising.csv')
df.shape