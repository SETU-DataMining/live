# See https://stackoverflow.com/a/55654661/1988855
colours = ['trueBlue', 'orange', 'mustard']
colorSet = dict(zip(featureNames, colours))
fig, ax = plt.subplots()
ax.set_xlabel('Advertising [1000 $]')
ax.set_ylabel('Sales [Thousands of units]')
title=ax.set_title("Sales vs. Advertising", weight="bold")

# Plot Sales vs. Advertising spend per channel

for featureName in colorSet:
  color = cs.ibm5col[colorSet[featureName]]
  ax.plot(X3[featureName], y, 'o', color=color, label=featureName)