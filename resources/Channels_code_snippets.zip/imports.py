import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import colours.colorsafe as cs
import seaborn as sns
import os
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_validate
from sklearn.preprocessing import MinMaxScaler