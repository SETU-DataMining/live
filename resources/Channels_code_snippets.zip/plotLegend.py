# See https://stackoverflow.com/a/10129461/1988855
# ask matplotlib for the plotted objects and their labels
lines, labels = ax.get_legend_handles_labels()
ax.legend(lines, labels, loc='lower right')