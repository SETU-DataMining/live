scoresDf3 = deriveScoresDf(X3)
display(scoresDf3[["feature", "test_neg_mean_squared_error", "test_r2"]])