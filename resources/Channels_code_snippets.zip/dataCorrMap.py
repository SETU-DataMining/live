# See https://seaborn.pydata.org/tutorial/color_palettes.html
cmap = sns.color_palette("Blues", as_cmap=True)
for method in ('pearson', 'kendall', 'spearman'):
  mCorr = df.corr(method=method)
  hm = sns.heatmap(mCorr, square=True, vmin=0, vmax=1, cmap=cmap)
  # See https://stackoverflow.com/a/47765118/1988855
  fig = hm.get_figure()
  fig.savefig('res/{}CorrHeatmap.pdf'.format(method))
  plt.title(f"{method} correlation (features and target)")
plt.show()
display(mCorr)
plt.show()
