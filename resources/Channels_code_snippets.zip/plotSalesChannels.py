target = 'Sales'
for feature in colorSet:
  color = cs.ibm5col[colorSet[feature]]
  ax.plot(df[feature], df[target], 'o', color=color, label=feature)