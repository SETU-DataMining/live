scoresDf4 = deriveScoresDf(X4)
display(scoresDf4[["feature", "test_neg_mean_squared_error", "test_r2"]])