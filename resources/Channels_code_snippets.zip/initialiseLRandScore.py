model = LinearRegression(fit_intercept=True)
metric = ('neg_mean_squared_error', 'r2') # see https://scikit-learn.org/1.5/modules/model_evaluation.html#scoring-parameter