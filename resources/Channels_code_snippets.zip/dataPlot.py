fig.savefig('res/data.pdf', bbox_inches='tight')
plt.show()
